package com.scorpio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YuEurekaServer1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
